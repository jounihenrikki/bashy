#!/bin/bash
# optional bashy.bash configuration file

# something is wrong if shell level is above 100
(( SHLVL < 100 )) || fatal "Shell level ($SHLVL) too high"

# uncomment to inhibit all logging
#declare log_inhibit=

# uncomment to add mandatory or ?optional libraries for all scripts
bashy_source+=( "?log" "?color" )

return 0
