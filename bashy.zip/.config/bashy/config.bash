#!/bin/bash
# optional bashy.bash configuration file

# uncomment to add mandatory or ?optional libraries for all scripts
bashy_source+=( "?log" "?color" )

return 0
