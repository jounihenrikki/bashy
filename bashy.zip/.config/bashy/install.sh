#!/bin/bash
usage() { cat <<-!EOF

NAME
  $1 - install bashy hook to login script

SYNOPSIS
  $1 [ options ]

DESCRIPTION
  Add 'bashrc' source command to user's ~/.bashrc file.
  Source command to add inside tag lines:
  $(source_command)

  Subsequent executions of $1 do not add multiple lines.

  Options
  -h  Show this help page
  -u  Uninstall. Remove source command

AUTHOR
  https://github.com/jounihenrikki/bashy/

!EOF
  exit 0
}

set -o errexit
set -o errtrace

error() { printf>&2 "%s(%s): %s\n" "$0" "${FUNCNAME[1]}" "$1"; }
fatal() { error "$*"; exit 1; }
trap 'fatal "line ${LINENO}: non-zero exit code: $?"' ERR

declare author="bashy"
declare rcfile=~/.bashrc
printf -v backup "${rcfile}.backup_%(%F_%H:%M:%S)T" -1

source_command() {
  printf "%s\n" "if [[ -r ~/.config/bashyrc ]]; then . ~/.config/bashyrc; fi"
}

declare action=install
while getopts hu OPT; do
  case $OPT in
    h) usage ${0##*/} ;;
    u) action="uninstall" ;;
    *) exit 1 ;
  esac
done
shift $(( OPTIND - 1 ))

# function copied from lib/embed.bash
# Parameters: tag file < input
embed.put() {
  local tag=${1:-insert} target=$2

  local tag1="<${tag}-begin>"
  local tag2="<${tag}-end>"
  local prefix=${embed_prefix-'# '}
  local suffix=${embed_suffix:-" managed by ${0##*/}, do not edit manually!"}
  {
    cat <<-!EOF
/${tag1}/,/${tag2}/d
\$a
${prefix}${tag1}${suffix}
!EOF
    cat
    cat <<-!EOF
${prefix}${tag2}${suffix}
.
w
q
!EOF
  } | ed -s ${target} >/dev/null 2>&1 ||:
  return 0
}

# Parameters: tag file
embed.clear() {
  local tag=${1:-insert} target=$2

  local tag1="<${tag}-begin>"
  local tag2="<${tag}-end>"
  cat <<-!EOF | ed -s ${target} > /dev/null 2>&1
/${tag1}/,/${tag2}/d
w
q
!EOF
  return $?
}

[[ -f ${rcfile} ]] || fatal "file doesn't exist: ${rcfile}"

case ${action} in
  install)
    cp "${rcfile}" "${backup}"
    embed.put "${author}" "${rcfile}" < <( source_command )
    ;;
  uninstall)
    cp "${rcfile}" "${backup}"
    embed.clear "${author}" "${rcfile}"
    ;;
esac

