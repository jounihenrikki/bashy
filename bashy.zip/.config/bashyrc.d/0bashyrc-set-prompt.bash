#!/bin/bash

# return here if shell is noninteractive
[[ $- == *i* ]] || return 0

# Set prompt in 256-color scheme. Examples:
# 39 light blue
# 40 green
# 214 light orange
# 229 light yellow
bashyrc.set-prompt() {
  local -i c1=${1:-229} c2=${2:-39}
  [[ -t 1 ]] || return 0
  (( $(tput colors) < 256 )) && return 0
  export PS1="[\[\e[38;5;${c1}m\]\u@\h:\[\e[38;5;${c2}m\]\W\[\e[0m\]]\$ "
}

