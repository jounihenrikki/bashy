#!/bin/bash
bashyrc-complete.help() { cat <<-!EOF

NAME
  bashyrc-complete - Bashy login scripts for command completion

DESCRIPTION
  Functions used for command completion

FUNCTIONS
  bashyrc.complete
    Available if complete package is installed.
    Function is used in compspec for script command completion.
    Function executes the scripts itself with option --.setopt.compgen

  bashyrc.complete-alias <command> <alias>
    Available if complete package is installed.
    Can be used in user login scripts to copy a compspec for aliases.
    Only one level of aliases supported.

  bashyrc.complete-rebuild
    Available if complete package is installed.
    Prints compspecs for validated bashy scripts in specified directory.

  bashyrc.complete-refresh (alias complete-refresh)
    Available if complete package is installed.
    Refresh compspecs for bashy scripts for current shell.
    Calls complete.rebuild if any script has been changed.
    Can be used interactively to apply compspecs for new scripts.

VARIABLES
  bashyrc_complete_alias
    Associative array used to resolve aliases in command completion.
    Set by bashyrc.complete-alias() and used in bashyrc.complete().

FILES
  ~/.config/bashyrc.d/0bashyrc-complete.bash
    This file

AUTHOR
  https://github.com/jounihenrikki/bashy/

!EOF
}


# return if not interactive shell
[[ $- == *i* ]] || return 0

declare -A bashyrc_complete_alias=()

# Completion function used for scripts, smuggles COMP_* arrays into script
# How to resolve aliases?
bashyrc.complete() {
  local cmd="$1" cur="$2" prev="$3"
  compopt -o nospace -o default -o nosort
  cmd=${bashyrc_complete_alias[${cmd}]-${cmd}}
  # bashyrc.debug-names cmd cur prev "${!COMP_@}" # uncomment to debug variables
  readarray -t COMPREPLY < <(BASH_ENV=<(declare -p "${!COMP_@}") ${cmd} --.setopt.compgen "$@")
}

# copy compspec of name $1 for aliases
bashyrc.complete-alias() {
  local cmd="$1" aliases=( "${@:2}" ) compspec=
  compspec=$(complete -p ${cmd}) && ${compspec} "${aliases[@]}"
  local alias=
  for alias in "${aliases[@]}"; do
    bashyrc_complete_alias[${alias}]="${cmd}"
  done
}

# Write compspecs for scripts in specified directory to stdout
bashyrc.complete-rebuild() {
  local path="$1"
  local command exefile
  local regex='^[^#]*setopt.check-options'
  if [[ ! -d "${path}" ]]; then
    printf>&2 "%s: %s\n" "${FUNCNAME}" "executable path not found: ${path}"
    return 0
  fi
  for command in $(find ${path} -mindepth 1 -maxdepth 1 -executable -printf '%P\n'); do
    # check command is found in PATH
    exefile=$(type -P "${command}") || continue
    # check command is compatible with setopt
    [[ $(file ${exefile}) == *Bourne-Again* ]] || continue
    # check that script looks compliant inside
    grep -q "${regex}" "${exefile}" || continue
    printf 'complete -F bashyrc.complete %s\n' "${command}"
  done
}

# Refresh compspecs for bashy scripts for current shell.
# Calls complete.rebuild if any script has been changed
# Can be used interactively to refresh compspecs
alias complete-refresh=bashyrc.complete-refresh
bashyrc.complete-refresh() {
  local base=${1:-${bashy_home:-${HOME}}}
  local path="${base}/.local/bin"
  local compspec=${base}/.config/compspec
  local -i rebuild=1
  # exit silently if script path not found
  [[ -d "${path}" ]] || return 0
  # exit silently if no write access to compspec directory
  [[ -w "${compspec%/*}" ]] || return 0
  if [[ -f ${compspec} ]]; then
    # skip rebuild if we have no write access to directory
    if [[ ! -w ${compspec%/*} ]]; then
      rebuild=0
    # or if directory modification times are not newer than compspec file
    elif ! [[ "$(find ${path} -maxdepth 0 -newer ${compspec} )" ]]; then
      rebuild=0
    fi
  fi
  if (( rebuild )); then
    bashyrc.complete-rebuild ${path} >| ${compspec} || return 1
  fi
  source ${compspec}
}

bashyrc.complete-refresh


