#!/bin/bash
bashyrc-complete.help() { cat <<-!EOF

NAME
  bashyrc-complete - Bashy login scripts for command completion

DESCRIPTION
  Functions used for command completion

FUNCTIONS
  bashyrc.complete
    Available if complete package is installed.
    Function is used in compspec for script command completion.
    Function executes the scripts itself with option --.setopt.compgen

  bashyrc.complete-alias <command> <alias>
    Available if complete package is installed.
    Can be used in user login scripts to copy a compspec for aliases.
    Only one level of aliases supported.

  bashyrc.complete-rebuild
    Available if complete package is installed.
    Prints compspecs for validated bashy scripts in specified directory.

  bashyrc.complete-refresh
  alias: complete-refresh
    Available if complete package is installed.
    Refresh compspecs for bashy scripts for current shell.
    Calls complete.rebuild if any script has been changed.
    Can be used interactively to apply compspecs for new scripts.

VARIABLES
  bashyrc_compspec
    Point to file with compspec definitions for Bashy scripts

  bashyrc_comppath
    Colon separated paths to scan when refreshing compspecs.

  bashyrc_complete_alias
    Associative array used to resolve aliases in command completion.
    Set by bashyrc.complete-alias() and used in bashyrc.complete().

FILES
  ~/.config/bashyrc.d/0bashyrc-complete.bash
    This file

AUTHOR
  https://github.com/jounihenrikki/bashy/

!EOF
}

# return if not interactive shell
[[ $- == *i* ]] || return 0

declare -A bashyrc_complete_alias=()
export bashyrc_comppath="${bashy_home:-${HOME}}/.local/bin"
export bashyrc_compspec="${bashy_home:-${HOME}}/.config/compspec"

# Completion function used for scripts, smuggles COMP_* arrays into script
# How to resolve aliases?
bashyrc.complete() {
  local cmd="$1" cur="$2" prev="$3"
  compopt -o nospace -o default -o nosort
  cmd=${bashyrc_complete_alias[${cmd}]-${cmd}}
  #bashyrc.debug-names cmd cur prev "${!COMP_@}" # uncomment to debug variables
  # set log_inhibit in subshell to inhibit logging. see log.bashy
  readarray -t COMPREPLY < <(BASH_ENV=<(declare -p "${!COMP_@}") log_inhibit= ${cmd} --.setopt.compgen "$@")
}

# copy compspec of name $1 for aliases
bashyrc.complete-alias() {
  local cmd="$1" aliases=( "${@:2}" ) compspec=
  compspec=$(complete -p ${cmd}) && ${compspec} "${aliases[@]}"
  local alias=
  for alias in "${aliases[@]}"; do
    bashyrc_complete_alias[${alias}]="${cmd}"
  done
}

# Return here if we have no write access to compspec directory (as a guest)
if [[ ! -w ${bashyrc_compspec%/*} ]]; then
  if [[ -r ${bashyrc_compspec} ]]; then
    source ${bashyrc_compspec}
  fi
  return 0
fi

# Write compspecs for scripts in specified directory
bashyrc.complete-rebuild() {
  local comppath=( "$@" )
  local path= command= exefile=
  local regex='^[^#]*setopt.check-options'
  for path in "${comppath[@]}"; do
    [[ -d "${path}" ]] || continue
    for command in $(find ${path} -mindepth 1 -maxdepth 1 -executable -printf '%P\n'); do
      # check command is found in PATH
      exefile=$(type -P "${command}") || continue
      # check command is compatible with setopt
      [[ $(file ${exefile}) == *Bourne-Again* ]] || continue
      # check that script looks compliant inside
      grep -q "${regex}" "${exefile}" || continue
      printf 'complete -F bashyrc.complete %s\n' "${command}"
    done
  done
}

# Refresh script compspec file. Can be used interactively.
alias complete-refresh=bashyrc.complete-refresh
bashyrc.complete-refresh() {
  if  [[ -f ${bashyrc_compspec} ]]; then
    [[ -w ${bashyrc_compspec} ]] || return 0
  fi
  local -i rebuild=1
  local path= comppath=()
  # split path elements to array
  readarray -t comppath < <(IFS=: read -ra a <<< "${bashyrc_comppath}"; printf "%s\n" "${a[@]}")
  # rebuild compspec if it doesn't exist or any executable is newer
  if [[ -f ${bashyrc_compspec} ]]; then
    [[ -n $(find "${comppath[@]}" -mindepth 1 -maxdepth 1 -executable -newer ${bashyrc_compspec} 2>/dev/null) ]] || rebuild=0
  fi
  (( rebuild )) && bashyrc.complete-rebuild "${comppath[@]}" >| ${bashyrc_compspec}
  if [[ -r ${bashyrc_compspec} ]]; then
    source ${bashyrc_compspec}
  fi
}

bashyrc.complete-refresh

