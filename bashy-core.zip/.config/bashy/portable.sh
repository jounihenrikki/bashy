#!/bin/bash
usage() { cat <<-!EOF

NAME
  $1 - 

SYNOPSIS
  $1 [ options ] 

DESCRIPTION
  ...

  Options:
    -h  Show this help page

    Double dash (--) can be used to signify the end of command options.

  Arguments:

  Examples:

!EOF
  exit 0
}

set -Eeuo pipefail
error() { printf>&2 "%s(%s): %s\n" "$0" "${FUNCNAME[1]}" "$1"; }
fatal() { error "$*"; exit 1; }
debug() { [[ -t 2 ]] && declare>&2 -p "${@}" 2>&1 ||true; }
trap 'fatal "line ${LINENO}: non-zero exit code: $?"' ERR

while getopts :h- OPT; do
  case $OPT in
    -) break ;;
    h) usage ${0##*/} ;;
    :) fatal "option requires argument -- ${OPTARG}" ;;
    \?) fatal "illegal option -- ${OPTARG}" ;;
    *) fatal "unsupported option -- ${OPT}" ;;
  esac
done
shift $(( OPTIND - 1 ))

# (( $# )) || fatal "missing parameters:$(printf " '%s'" "$@")"


