#!/bin/bash
bashy.help() { bashy.pphelp <<-!EOF

Name
  $1 -

Description
  ...

Functions
  ...

Variables
  ...

Files
  \${bashy_config_home}/$1.bash/
    Configuration files

Dependencies

Author

!EOF
exit
}

# Global variables required by help (use prefix <name>_):


[[ "${1-}" == "--help" ]] && bashy.help "${BASH_SOURCE##*/}"

# Comment out to allow sourcing multiple times
(( bashy_sourced[$(basename "${BASH_SOURCE}" .bash)] )) && return 0

# Log source file usage
bashy.log-usage

# Uncomment for each library dependancy. Mask positional arguments
#(( bashy_sourced[...] )) || source $(bashy.lib-path ...) --


# Global state variables (prefix: <name>_):


# Functions (prefix: <name>.):


return 0
